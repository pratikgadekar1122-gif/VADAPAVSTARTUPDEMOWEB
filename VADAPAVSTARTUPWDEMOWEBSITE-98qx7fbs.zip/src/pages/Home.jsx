import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Zap, Clock, Star } from 'lucide-react';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';

const Home = () => {
  const featuredProducts = products.slice(0, 3);
  return (
    <div className="animate-fadeIn">
      <section className="relative h-[85vh] flex items-center bg-yellow-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
          <div className="lg:w-1/2 pr-8">
            <span className="inline-block bg-orange-100 text-orange-600 px-4 py-2 rounded-full text-sm font-bold mb-6">MUMBAI'S #1 STREET FOOD</span>
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 leading-tight mb-6">Mumbai’s Favourite <span className="text-orange-600">VadaPav</span>.<br/>Now Ready To Eat.</h1>
            <p className="text-xl text-gray-600 mb-8 max-w-lg">Authentic taste, hygienic packing, and ready in just 2 minutes.</p>
            <div className="flex gap-4">
              <Link to="/menu" className="bg-orange-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-700 transition flex items-center justify-center gap-2 shadow-lg">Explore Menu <ArrowRight size={20} /></Link>
            </div>
          </div>
        </div>
      </section>
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-12">Just 3 Steps</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[{ icon: <ShieldCheck size={40} />, title: "1. Tear Open", desc: "Hygienic vacuum sealed." }, { icon: <Zap size={40} />, title: "2. Heat It", desc: "Microwave 60s." }, { icon: <Clock size={40} />, title: "3. Enjoy", desc: "Taste the fresh flavors." }].map((step, i) => (
              <div key={i} className="p-8 rounded-3xl bg-orange-50"><div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-orange-500 shadow-md">{step.icon}</div><h3 className="text-xl font-bold mb-3">{step.title}</h3><p className="text-gray-600">{step.desc}</p></div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
export default Home;
