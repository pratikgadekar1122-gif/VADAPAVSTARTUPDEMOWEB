import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { Trash2, Plus, Minus, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal, clearCart } = useCart();
  const [placed, setPlaced] = useState(false);

  if (placed) return <div className="min-h-screen flex flex-col items-center justify-center"><CheckCircle size={64} className="text-green-600 mb-4"/><h2 className="text-3xl font-bold">Order Placed!</h2><Link to="/menu" className="text-orange-600 mt-4 font-bold">Order More</Link></div>;
  if (cart.length === 0) return <div className="min-h-[70vh] flex flex-col items-center justify-center"><h2 className="text-2xl font-bold text-gray-400">Cart is empty</h2><Link to="/menu" className="text-orange-600 font-bold">Browse Menu</Link></div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Your Cart</h1>
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6 space-y-6">
          {cart.map(item => (
            <div key={item.id} className="flex justify-between items-center border-b pb-4 last:border-0">
              <div className="flex items-center gap-4">
                <img src={item.image} className="w-16 h-16 rounded-lg object-cover" />
                <div><h3 className="font-bold">{item.name}</h3><p className="text-orange-600">₹{item.price}</p></div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center bg-gray-100 rounded-lg"><button onClick={() => updateQuantity(item.id, -1)} className="p-2"><Minus size={16}/></button><span className="w-8 text-center font-bold">{item.quantity}</span><button onClick={() => updateQuantity(item.id, 1)} className="p-2"><Plus size={16}/></button></div>
                <button onClick={() => removeFromCart(item.id)} className="text-red-500"><Trash2 size={20}/></button>
              </div>
            </div>
          ))}
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex justify-between text-xl font-bold mb-6"><span>Total</span><span>₹{cartTotal}</span></div>
          <button onClick={() => {setPlaced(true); clearCart();}} className="w-full bg-orange-600 text-white py-4 rounded-xl font-bold hover:bg-orange-700">Checkout</button>
        </div>
      </div>
    </div>
  );
};
export default Cart;
