import React from 'react';
const About = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="h-64 bg-orange-100 flex items-center justify-center"><h1 className="text-5xl font-bold text-orange-900">Our Story</h1></div>
      <div className="max-w-4xl mx-auto px-4 py-16">
        <div className="bg-orange-50 p-8 rounded-3xl border-l-8 border-orange-500 shadow-sm mb-12">
          <h2 className="text-2xl font-bold text-orange-800 mb-6">Aapla VadaPav, Navya Rupaat.</h2>
          <p className="text-gray-700 italic text-lg leading-loose">“VadaPav ha fakt ek snack nahi, to Mumbai chi food heritage ahe. Pan kal badalla, lifestyle badalli. Ha atishay lokpriya pn durmil hot chalela khadyapadarth, ata tumhala milnar aahe navin rupat. Ready To Eat VadaPav mhanje authentic taste, hygienic process, ani convenience.”</p>
        </div>
      </div>
    </div>
  );
};
export default About;
