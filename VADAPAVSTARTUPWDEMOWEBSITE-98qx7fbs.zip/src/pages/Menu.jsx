import React, { useState } from 'react';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';
import { Search } from 'lucide-react';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const categories = ['All', 'Classic', 'Cheese', 'Spicy', 'Jain', 'Healthy'];

  const filtered = products.filter(p => (activeCategory === 'All' || p.category === activeCategory) && p.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen bg-gray-50 pt-8 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Menu</h1>
          <div className="max-w-md mx-auto relative mb-8">
            <input type="text" placeholder="Search..." className="w-full pl-10 pr-4 py-3 rounded-full border focus:outline-none focus:border-orange-500" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            <Search className="absolute left-3 top-3 text-gray-400" size={20} />
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map(cat => <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-6 py-2 rounded-full text-sm font-semibold transition ${activeCategory === cat ? 'bg-orange-600 text-white' : 'bg-white text-gray-600 border'}`}>{cat}</button>)}
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filtered.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </div>
  );
};
export default Menu;
