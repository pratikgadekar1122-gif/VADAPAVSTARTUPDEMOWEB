import React from 'react';
import { Plus, Flame } from 'lucide-react';
import { useCart } from '../context/CartContext';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  return (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 group">
      <div className="relative h-48 overflow-hidden">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"/>
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-bold text-gray-800 shadow-sm">₹{product.price}</div>
        {product.spicyLevel > 2 && <div className="absolute top-3 left-3 bg-red-500/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-bold text-white shadow-sm flex items-center gap-1"><Flame size={12} fill="white" /> Spicy</div>}
      </div>
      <div className="p-5">
        <h3 className="text-lg font-bold text-gray-800 leading-tight mb-2">{product.name}</h3>
        <p className="text-gray-500 text-sm mb-4 line-clamp-2 h-10">{product.description}</p>
        <div className="flex justify-between items-center mt-4">
          <span className="text-sm font-semibold text-gray-400">{product.category}</span>
          <button onClick={() => addToCart(product)} className="flex items-center gap-1 bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-full text-sm font-medium transition-colors active:scale-95">
            <Plus size={16} /> Add
          </button>
        </div>
      </div>
    </div>
  );
};
export default ProductCard;
